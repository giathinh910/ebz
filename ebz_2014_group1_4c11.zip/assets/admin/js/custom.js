(function( $ ) {
	$(document).ready(function() {
		$('.data-table').dataTable();
	})
})( jQuery ); // EOF